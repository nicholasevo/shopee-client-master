export default interface DeleteCategoryRequest {
  /**
   * ShopCategory's unique identifier.
   */
  shop_category_id: number
}
export default interface GetItemsRequest {
  /**
   * ShopCategory's unique identifier.
   */
  shop_category_id: number, 
}
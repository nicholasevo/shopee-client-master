import AddDiscountResponse from "./AddDiscountResponse";

export default interface AddDiscountItemResponse extends AddDiscountResponse {
  
}
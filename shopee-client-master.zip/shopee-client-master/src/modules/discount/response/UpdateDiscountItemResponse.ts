import AddDiscountResponse from "./AddDiscountResponse";

export default interface UpdateDiscountItemResponse extends AddDiscountResponse{

}

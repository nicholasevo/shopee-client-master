export default interface BoostRequest {
  /**
   * A list of item ids to be boosted. You can input a maximum of 5 items per request.
   */
  item_id: number[],
}
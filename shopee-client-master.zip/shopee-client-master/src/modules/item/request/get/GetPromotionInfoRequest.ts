export default interface GetPromotionInfoRequest {
  /**
   * The list of item_id. Up to 50 item_ids in one call.
   */
  item_id_list: number[],
}
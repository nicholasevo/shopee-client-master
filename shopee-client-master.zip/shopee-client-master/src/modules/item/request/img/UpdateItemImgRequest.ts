import AddItemImageRequest from "./AddItemImageRequest";

export default interface UpdateItemImgRequest extends AddItemImageRequest {
  
}
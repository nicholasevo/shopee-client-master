import UpdatePriceBatchResponse from "./UpdatePriceBatchResponse";

export default interface UpdateStockBatchResponse extends UpdatePriceBatchResponse {

}
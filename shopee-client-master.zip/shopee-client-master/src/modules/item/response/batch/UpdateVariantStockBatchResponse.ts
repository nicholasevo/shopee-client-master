import UpdateVariantPriceBatchResponse from "./UpdateVariantPriceBatchResponse";

export default interface UpdateVariantStockBatchResponse extends UpdateVariantPriceBatchResponse {

}
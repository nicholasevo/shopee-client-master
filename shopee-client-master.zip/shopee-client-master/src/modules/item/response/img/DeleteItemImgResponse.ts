export default interface DeleteItemImgResponse {
  /**
   * The identifier for an API request for error tracking
   */
  request_id: string,

}
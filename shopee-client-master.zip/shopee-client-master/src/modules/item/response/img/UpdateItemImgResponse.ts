import AddItemImageRequest from "../../request/img/AddItemImageRequest";

export default interface UpdateItemImgResponse extends AddItemImageRequest {
  
}
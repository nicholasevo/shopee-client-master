import InitTier2Response from "./InitTier2Response";

export default interface AddTierVariationResponse extends InitTier2Response {

}
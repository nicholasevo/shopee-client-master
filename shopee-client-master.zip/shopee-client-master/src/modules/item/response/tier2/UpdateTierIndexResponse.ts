import UpdateTierVariationResponse from "./UpdateTierVariationResponse";

export default interface UpdateTierIndexResponse extends UpdateTierVariationResponse {

}
export default interface SetAddressRequest {
  default_address_id?: number,
  pick_up_address_id?: number,
  return_address_id?: number,
}
import SetAddressResponse from "./SetAddressResponse";

export default interface DeleteAddressResponse extends SetAddressResponse {
  
}
export default interface SetAddressResponse {
  /**
   * The identifier for an API request for error tracking
   */
  request_id: string,
}
import CancelOrderResponse from "./CancelOrderResponse"; 

export default interface AccceptBuyerCancelResponse extends CancelOrderResponse {
  
}
import GetOrderListResponse from "./GetOrderListResponse";

export default interface GetOrderByStatusResponse extends GetOrderListResponse {

}
import CancelOrderResponse from "./CancelOrderResponse";

export default interface RejectBuyerCancelResponse extends CancelOrderResponse {

}
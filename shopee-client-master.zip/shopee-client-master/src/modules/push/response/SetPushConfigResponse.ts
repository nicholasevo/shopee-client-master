export default interface SetPushConfigResponse {
  /**
   * Use this field to indicate whether the configuration is set successfully.
   */
  status: string
}
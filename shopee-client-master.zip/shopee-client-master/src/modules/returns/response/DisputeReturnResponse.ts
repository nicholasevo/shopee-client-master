import ConfirmReturnResponse from "./ConfirmReturnResponse";

export default interface DisputeReturnResponse extends ConfirmReturnResponse {

}
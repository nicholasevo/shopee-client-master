export default interface setInstallmentResponse {
  /**
   * The status of whether shop support installment: 1 means true and 0 means false
   */
  installment_status: boolean;
}
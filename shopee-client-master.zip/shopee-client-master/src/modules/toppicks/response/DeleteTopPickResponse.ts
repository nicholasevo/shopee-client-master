export default interface DeleteTopPickResponse {
  /**
   * collection Id
   */
  top_picks_id: number
}
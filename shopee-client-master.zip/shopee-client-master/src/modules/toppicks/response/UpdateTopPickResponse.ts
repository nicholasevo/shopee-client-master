import AddTopPickResponse from "./AddTopPickResponse";

export default interface UpdateTopPickResponse extends AddTopPickResponse {

}